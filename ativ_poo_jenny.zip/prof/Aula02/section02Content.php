Neste arquivo estará o conteúdo do Sessão 02
<input type="button" id="btnSct02" value="Carregar Section 3">   

<script type="text/javascript">
	$(document).ready(function() {
		$("#btnSct02").click(function() {
			$("#sct01" ).load("section03Content.php");
		});
	});
</script>