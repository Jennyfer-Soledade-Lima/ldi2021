Neste arquivo estará o conteúdo do Sessão 04
<?php 

$user = $_REQUEST['user'];
$pass = $_REQUEST['pass'];

if( isset($_REQUEST['user']) && isset($_REQUEST['pass'])){
    echo "<br> O usuario pra Login: ".$user." e Senha:".$pass;
} else {
    echo "<br> O usuario pra Login e Senha não informados";
    
}



?>