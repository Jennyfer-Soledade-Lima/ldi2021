Neste arquivo estará o conteúdo do Sessão 03
<form id="frmLogin">
	User:  <input type="text" name="user" ><br>
	Senha: <input type="password" name="pass"><br>
	<input type="button" id="btnEnviar" value="Enviar">
</form>


<script type="text/javascript">
	$(document).ready(function() {
		$("#btnEnviar").click(function() {
			var url   = "section04Content.php";
			var dados = $("#frmLogin").serialize();
			$.post( url, dados, function( responseText ) {
				$("#sct02" ).html( responseText );
			} );
		});
	});
</script>