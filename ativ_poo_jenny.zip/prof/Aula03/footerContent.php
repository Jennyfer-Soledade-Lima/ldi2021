<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
    </head>
    <body>
        <h1>
            Sobre - Minha História
        </h1>
        <p>
            Mulheres como Grace Hopper, Jean Sammet são uma grande inspiração para mim.<br>
            A sede por sabedoria, vem pelo contato com o conhecimento. Se essas mulheres nunca tivesse tido a chance de ter um contato com a tecnologia,
             talvez não soubessemos os nomes e a importância que elas tem para nosso  mundo tecnologico. <br>
            Estou entrando nesse assunto porque o meu desejo e interresse por essa área só chegou quando entrei no IFSP ( Instituto Federal de Guarulhos). Esse contato com 
            um novo saber ( informática ) me levou a conhecer de mim,lados e gostos que não sabia. Hoje tem grande apreço pela tecnologia prentendo me formar na área. E me dedicar para me torna melhor do já sou.
        </p>
    </body>
</html>