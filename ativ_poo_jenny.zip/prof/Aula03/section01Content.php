<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilo.css"/>
	
</head>
<body>
	<div class="banner">
	<div class="imagem1">
		<img src="img/laptop2.png">
	</div>
		<h2>OLÁ ! EU SOU.</h2>
		<h1> Jennyfer Soledade.</h1>
		<h3>Estudante técnica em Informática para internet</h3>
	</div>
	</video>
</body>



</html>