

<div class="perfil">
<img src="img/foto_minha.jpeg">
<h2>Jennyfer Soledade</h2>
<p>Estudante de Informática para internet <br>
no Instituto Federal de Ciências e Tecnolgias <br>
de São Paulo - câmpus Guarulhos</p><br>
<p>jennyfer.lima@aluno.ifsp.edu.br</p>
<p>(11) 2005-3456</p><br>
<img src="img/redes.JPG"><br>
</div>



<div class="botao">
<input type="button" id="btnSct02" value="Entrar em contato">   
</div>
<script type="text/javascript">
	$(document).ready(function() {
		$("#btnSct02").click(function() {
			$("#sct01" ).load("section03Content.php");
		});
	});
</script>