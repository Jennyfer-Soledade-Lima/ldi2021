<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" type="text/css" href="css/estilo.css"/>
    </head>
    <body>
   <!-- <div class="menu"> -->
        <ul>
            <li><a href="front0.php">Home</a></li>
            <li><a href="*">Entrar em contato</a></li>
            <li><a href="footerContent.php">Acadêmico</a></li>
            
        </ul>
  <!--  </div> -->

    </body>

</script>
</html>